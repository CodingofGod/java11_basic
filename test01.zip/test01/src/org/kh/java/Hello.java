package org.kh.java;

public class Hello {
	public static void main(String[] args) {	//실행을 위한 기본 main 메소드 = ctal+/ = 한줄 각주
		System.out.println("Hello~! \nJAVA");
		/*
		자기 이름 소개하는
		출력 명령
		결과 : My name is kangminwoo = ctrl+shift+/ = 여러 줄 각주
		 */
		//sysout => Ctrl+Spacebar = 단축명령 자동 완성(Code Hinting)
		System.out.println("my name is kangminwoo");
	}
}