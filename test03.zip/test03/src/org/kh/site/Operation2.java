package org.kh.site;
//산술 연산(Arithmetic) => 논리 연산 (Logical)
public class Operation2 {
	public static void main(String[] args) {
		//+, -, *, /, %
		int su1 = 98;
		int su2 = 18;
		System.out.println("su1 + su2 = "+(su1 + su2));
		System.out.println("su1 - su2 = "+(su1 - su2));
		System.out.println("su1 * su2 = "+(su1 * su2));
		System.out.println("su1 / su2 = "+(su1 / su2));
		System.out.println("su1 % su2 = "+(su1 % su2)); // 98 / 18 =
		
		
		
	}

}
